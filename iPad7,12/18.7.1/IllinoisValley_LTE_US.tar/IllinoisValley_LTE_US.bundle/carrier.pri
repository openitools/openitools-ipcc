<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>Maverick</key>
	<dict>
		<key>Carrier ID</key>
		<string></string>
		<key>Maverick SD Configuration Items</key>
		<dict>
			<key>Maverick SD Config Count</key>
			<integer>25</integer>
			<key>Maverick SD Config Items</key>
			<array>
				<integer>1</integer>
				<integer>3</integer>
				<integer>1</integer>
				<integer>20</integer>
				<integer>180</integer>
				<integer>180</integer>
				<integer>180</integer>
				<integer>180</integer>
				<integer>60</integer>
				<integer>1</integer>
				<integer>180</integer>
				<integer>2</integer>
				<integer>20</integer>
				<integer>3</integer>
				<integer>60</integer>
				<integer>300</integer>
				<integer>120</integer>
				<integer>30</integer>
				<integer>60</integer>
				<integer>180</integer>
				<integer>180</integer>
				<integer>0</integer>
				<integer>0</integer>
				<integer>1200</integer>
				<integer>28</integer>
			</array>
		</dict>
		<key>PRI Revision</key>
		<string>0.1.161</string>
	</dict>
	<key>CDMA</key>
	<dict>
		<key>CDMA1X ADV Capability</key>
		<false/>
		<key>CDMA1X PREV</key>
		<integer>6</integer>
		<key>Custom Home ERI</key>
		<array>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
		</array>
		<key>OTA Features</key>
		<dict>
			<key>OTA Features Count</key>
			<integer>6</integer>
			<key>OTA Features ID</key>
			<array>
				<integer>0</integer>
				<integer>1</integer>
				<integer>2</integer>
				<integer>2</integer>
				<integer>3</integer>
				<integer>4</integer>
				<integer>65535</integer>
				<integer>65535</integer>
				<integer>65535</integer>
				<integer>65535</integer>
			</array>
			<key>OTA Features P Rev</key>
			<array>
				<integer>2</integer>
				<integer>2</integer>
				<integer>1</integer>
				<integer>3</integer>
				<integer>1</integer>
				<integer>1</integer>
				<integer>65535</integer>
				<integer>65535</integer>
				<integer>65535</integer>
				<integer>65535</integer>
			</array>
		</dict>
		<key>OTASP System Selection Codes</key>
		<dict>
			<key>OTASP SS Codes</key>
			<array>
				<integer>101</integer>
				<integer>101</integer>
				<integer>101</integer>
				<integer>101</integer>
				<integer>101</integer>
				<integer>101</integer>
				<integer>101</integer>
				<integer>101</integer>
				<integer>101</integer>
				<integer>101</integer>
				<integer>101</integer>
				<integer>101</integer>
				<integer>101</integer>
				<integer>101</integer>
				<integer>101</integer>
				<integer>101</integer>
				<integer>101</integer>
				<integer>100</integer>
				<integer>100</integer>
				<integer>100</integer>
				<integer>100</integer>
				<integer>100</integer>
				<integer>100</integer>
				<integer>100</integer>
				<integer>100</integer>
				<integer>100</integer>
				<integer>100</integer>
				<integer>100</integer>
				<integer>100</integer>
			</array>
		</dict>
		<key>SD Configuration Items</key>
		<dict>
			<key>SD Config Count</key>
			<integer>25</integer>
			<key>SD Config Items</key>
			<array>
				<integer>120</integer>
				<integer>180</integer>
				<integer>5</integer>
				<integer>1</integer>
				<integer>180</integer>
				<integer>180</integer>
				<integer>130</integer>
				<integer>180</integer>
				<integer>130</integer>
				<integer>14</integer>
				<integer>0</integer>
				<integer>0</integer>
				<integer>1</integer>
				<integer>1</integer>
				<integer>60</integer>
				<integer>120</integer>
				<integer>3</integer>
				<integer>253</integer>
				<integer>900</integer>
				<integer>180</integer>
				<integer>300</integer>
				<integer>3600</integer>
				<integer>0</integer>
				<integer>3</integer>
				<integer>12</integer>
			</array>
			<key>SD Config Version</key>
			<integer>3</integer>
		</dict>
		<key>SID-MCC Association Table</key>
		<dict>
			<key>SID-MCC List</key>
			<array>
				<integer>20316296</integer>
				<integer>20316901</integer>
				<integer>21890549</integer>
				<integer>20320261</integer>
				<integer>20320270</integer>
				<integer>20320310</integer>
				<integer>20321892</integer>
				<integer>20321894</integer>
				<integer>20321932</integer>
				<integer>0</integer>
			</array>
			<key>SID-MCC Table Length</key>
			<integer>9</integer>
		</dict>
		<key>SO73 COP0 Support</key>
		<false/>
		<key>SO73 Enable</key>
		<false/>
	</dict>
	<key>Carrier Configuration Management</key>
	<dict>
		<key>CDMA 1X Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
		<key>Call Manager Feature Group</key>
		<array>
			<false/>
			<true/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
		<key>Data Service Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<true/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
		<key>EVDO Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
		<key>OMA Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
		<key>System Determination Feature Group</key>
		<array>
			<false/>
			<true/>
			<true/>
			<false/>
			<false/>
			<true/>
			<true/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
		<key>UIM Service Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
		<key>Wireless Messaging Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
	</dict>
	<key>Data Parameters</key>
	<dict>
		<key>3GPP2</key>
		<dict>
			<key>AN NAI</key>
			<string>Default:000000[pESN4]@ivcevdo.com</string>
			<key>AN Password</key>
			<string>Default:[HMEID]</string>
			<key>CTA Timer</key>
			<integer>30</integer>
			<key>DATA_AUTO_PACKET_DETECTION</key>
			<true/>
			<key>DATA_PKT_ORIG_STR</key>
			<string>#777</string>
			<key>DATA_SCRM_ENABLED</key>
			<true/>
			<key>DATA_SO_SET</key>
			<string>IS-707</string>
			<key>DATA_TRTL_ENABLED</key>
			<true/>
			<key>DNS Primary</key>
			<string>(0.0.0.0)</string>
			<key>DNS Secondary</key>
			<string>(0.0.0.0)</string>
			<key>DUN MIP NAI</key>
			<string>Default:000000[pESN4]@ivctethering.com</string>
			<key>DUN SIP NAI</key>
			<string>Default:[NULL]</string>
			<key>Dormant Handoff Optimization</key>
			<true/>
			<key>HA Pri IP Address</key>
			<string>Default:(255.255.255.255)</string>
			<key>HA Sec IP Address</key>
			<string>Default:(255.255.255.255)</string>
			<key>Home IP Address</key>
			<string>Default:(0.0.0.0)</string>
			<key>Hybrid_pref</key>
			<string>Hybrid</string>
			<key>MDR Mode</key>
			<string>MDR SO33</string>
			<key>MIP Dereg Retries</key>
			<string>1</string>
			<key>MIP MN-AAA Shared Secret</key>
			<string>Default:[HMEID]</string>
			<key>MIP MN-HA Shared Secret</key>
			<string>Default:736563726574</string>
			<key>MIP Mode</key>
			<string>MIP Only</string>
			<key>MIP NAI</key>
			<string>Default:000000[pESN4]@ivcdata.com</string>
			<key>MIP Pre-Reregistration Timeout</key>
			<integer>1</integer>
			<key>MIP Registration Retries</key>
			<integer>2</integer>
			<key>MIP Registration Retry Timeout</key>
			<integer>3</integer>
			<key>MN AAA SPI Set</key>
			<true/>
			<key>MN AAA SPI Value</key>
			<string>300</string>
			<key>MN HA SPI Set</key>
			<true/>
			<key>MN HA SPI Value</key>
			<integer>256</integer>
			<key>Max fallback PDN failure count</key>
			<integer>1</integer>
			<key>Mobile Node - HA Authentication</key>
			<string>RFC2002bis</string>
			<key>Number of Profiles</key>
			<integer>1</integer>
			<key>PREF_FOR_RC</key>
			<string>RC3</string>
			<key>QNC Enabled</key>
			<false/>
			<key>Reverse Tunneling</key>
			<true/>
			<key>SIP NAI</key>
			<string>Default:[NULL]</string>
			<key>SIP Password</key>
			<string>Default:[NULL]</string>
		</dict>
		<key>Enable IPv6</key>
		<false/>
	</dict>
	<key>EHRPD</key>
	<dict>
		<key>EMPA</key>
		<string>0</string>
		<key>Enable EHRPD</key>
		<false/>
		<key>HDRSCP Force AT Config</key>
		<string>1</string>
		<key>HDRSCP Session Re-negotiate</key>
		<true/>
	</dict>
	<key>Feature Settings</key>
	<dict>
		<key>HDR to LTE Reselection</key>
		<false/>
		<key>Handset Based Plus Code Dialing</key>
		<true/>
		<key>NAM_LOCK</key>
		<false/>
		<key>OTAPA Enabled</key>
		<true/>
		<key>Preferred Mode</key>
		<string>Automatic</string>
		<key>RTRE Config</key>
		<string>RUIM_CSIM_ONLY</string>
		<key>Rat Acq Order</key>
		<string>CLWGH</string>
		<key>Roam Preference</key>
		<string>Automatic</string>
		<key>System Select Preference</key>
		<string>Any</string>
		<key>UE Usage Setting</key>
		<string>1</string>
	</dict>
	<key>GERAN</key>
	<dict>
		<key>A5 Algorithm Supported</key>
		<string>A5_1</string>
		<key>GEA Algorithm Supported</key>
		<string>GEA_1</string>
	</dict>
	<key>JCDMA</key>
	<dict>
		<key>Enable JCDMA</key>
		<false/>
	</dict>
	<key>LTE</key>
	<dict>
		<key>Fplmn Backoff Time</key>
		<integer>4294967295</integer>
		<key>LTE1xCSFB Support</key>
		<false/>
	</dict>
	<key>NAM - CDMA Settings</key>
	<dict>
		<key>ACCOLOC</key>
		<string>Default:[pESN1]</string>
		<key>EVRC Capability</key>
		<dict>
			<key>EVRC B Enable</key>
			<false/>
			<key>EVRC Capability</key>
			<dict>
				<key>EVRC Enable</key>
				<true/>
				<key>Preferred voice service option for Home Origination</key>
				<string>EVRC_A</string>
				<key>Preferred voice service option for Home Page</key>
				<string>EVRC_A</string>
				<key>Preferred voice service option for Roam Origination</key>
				<string>EVRC_A</string>
			</dict>
		</dict>
		<key>Home SID/NID</key>
		<array>
			<string>1178/65535</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
		</array>
		<key>IMSI_S</key>
		<string>Default:000000[pESN4]</string>
		<key>MCC</key>
		<string>311</string>
		<key>MIN1</key>
		<string>Default:000[pESN4]</string>
		<key>MIN2</key>
		<string>Default:000</string>
		<key>MNC</key>
		<string>34</string>
		<key>Negative SID/NID</key>
		<array>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
		</array>
		<key>Primary Channel, A band</key>
		<integer>283</integer>
		<key>Primary Channel, B band</key>
		<integer>384</integer>
		<key>Register - Foreign NID</key>
		<true/>
		<key>Register - Foreign SID</key>
		<true/>
		<key>Register - Home SID</key>
		<true/>
		<key>Secondary Channel, A band</key>
		<integer>691</integer>
		<key>Secondary Channel, B band</key>
		<integer>777</integer>
		<key>Slot Cycle Index</key>
		<integer>2</integer>
		<key>Voice Privacy</key>
		<false/>
	</dict>
	<key>NAM - General</key>
	<dict>
		<key>MDN</key>
		<string>Default:000000[pESN4]</string>
	</dict>
	<key>SMS / EMS Settings</key>
	<dict>
		<key>MO-SMS SO</key>
		<string>SO_6 (8k)</string>
		<key>MO-SMS enable</key>
		<true/>
		<key>Resend Count</key>
		<integer>3</integer>
		<key>Transport Methods</key>
		<string>Traffic Channel</string>
	</dict>
	<key>SRLTE</key>
	<dict>
		<key>TRM RF Configuration</key>
		<string>2</string>
		<key>TRM RF Mask</key>
		<string>2</string>
	</dict>
	<key>Security Grouping</key>
	<dict>
		<key>Service Programming Code Change Enabled</key>
		<false/>
	</dict>
	<key>WCDMA</key>
	<dict>
		<key>AAGPS MODE</key>
		<string>1</string>
		<key>ANITE GCF</key>
		<false/>
		<key>HSDPA Category</key>
		<string>24</string>
		<key>HSUPA Category</key>
		<string>6</string>
	</dict>
</dict>
</plist>
