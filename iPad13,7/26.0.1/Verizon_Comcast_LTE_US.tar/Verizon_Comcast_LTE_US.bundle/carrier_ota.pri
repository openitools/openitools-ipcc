<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>Maverick</key>
	<dict>
		<key>Carrier ID</key>
		<string></string>
		<key>Maverick SD Configuration Items</key>
		<dict>
			<key>Maverick SD Config Count</key>
			<integer>25</integer>
			<key>Maverick SD Config Items</key>
			<array>
				<integer>1</integer>
				<integer>3</integer>
				<integer>1</integer>
				<integer>20</integer>
				<integer>180</integer>
				<integer>180</integer>
				<integer>180</integer>
				<integer>180</integer>
				<integer>60</integer>
				<integer>1</integer>
				<integer>180</integer>
				<integer>2</integer>
				<integer>20</integer>
				<integer>3</integer>
				<integer>60</integer>
				<integer>300</integer>
				<integer>0</integer>
				<integer>0</integer>
				<integer>0</integer>
				<integer>0</integer>
				<integer>0</integer>
				<integer>0</integer>
				<integer>0</integer>
				<integer>0</integer>
				<integer>0</integer>
			</array>
		</dict>
		<key>PRI Revision</key>
		<string>0.1.004</string>
	</dict>
	<key>CDMA</key>
	<dict>
		<key>Custom Home ERI</key>
		<array>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>3</integer>
			<integer>240</integer>
			<integer>15</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
			<integer>0</integer>
		</array>
		<key>SD Configuration Items</key>
		<dict>
			<key>SD Config Count</key>
			<integer>25</integer>
			<key>SD Config Items</key>
			<array>
				<integer>120</integer>
				<integer>180</integer>
				<integer>5</integer>
				<integer>1</integer>
				<integer>180</integer>
				<integer>180</integer>
				<integer>130</integer>
				<integer>180</integer>
				<integer>130</integer>
				<integer>14</integer>
				<integer>0</integer>
				<integer>0</integer>
				<integer>1</integer>
				<integer>0</integer>
				<integer>0</integer>
				<integer>0</integer>
				<integer>180</integer>
				<integer>253</integer>
				<integer>0</integer>
				<integer>0</integer>
				<integer>300</integer>
				<integer>0</integer>
				<integer>0</integer>
				<integer>3</integer>
				<integer>12</integer>
			</array>
			<key>SD Config Version</key>
			<integer>2</integer>
		</dict>
		<key>SID-MCC Association Table</key>
		<dict>
			<key>SID-MCC List</key>
			<array>
				<integer>20316296</integer>
				<integer>20316901</integer>
				<integer>21890549</integer>
				<integer>20320261</integer>
				<integer>20320270</integer>
				<integer>20320310</integer>
				<integer>20321892</integer>
				<integer>20321894</integer>
				<integer>20321932</integer>
				<integer>0</integer>
			</array>
			<key>SID-MCC Table Length</key>
			<integer>9</integer>
		</dict>
	</dict>
	<key>Carrier Configuration Management</key>
	<dict>
		<key>CDMA 1X Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
		<key>Call Manager Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
		<key>Data Service Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<true/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
		<key>EVDO Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<true/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
		<key>OMA Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
		<key>System Determination Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
		<key>UIM Service Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
		<key>Wireless Messaging Feature Group</key>
		<array>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
			<false/>
		</array>
	</dict>
	<key>Data Parameters</key>
	<dict>
		<key>AN NAI</key>
		<string>Default:001[pESN7]@vzw3g.com</string>
		<key>AN Password</key>
		<string>Default:00000000000000000000000000000000</string>
		<key>CTA Timer</key>
		<integer>30</integer>
		<key>DATA_AUTO_PACKET_DETECTION</key>
		<true/>
		<key>DATA_PKT_ORIG_STR</key>
		<string>#777</string>
		<key>DATA_SCRM_ENABLED</key>
		<true/>
		<key>DATA_SO_SET</key>
		<string>IS-707</string>
		<key>DATA_TRTL_ENABLED</key>
		<true/>
		<key>DMU PKOID</key>
		<integer>10</integer>
		<key>DNS Primary</key>
		<string>(0.0.0.0)</string>
		<key>DNS Secondary</key>
		<string>(0.0.0.0)</string>
		<key>DUN MIP NAI</key>
		<string>Default:[NULL]</string>
		<key>DUN SIP NAI</key>
		<string>Default:[NULL]</string>
		<key>Dormant Handoff Optimization</key>
		<true/>
		<key>HA Pri IP Address</key>
		<string>(255.255.255.255)</string>
		<key>HA Sec IP Address</key>
		<string>(255.255.255.255)</string>
		<key>Home IP Address</key>
		<string>(0.0.0.0)</string>
		<key>Hybrid_pref</key>
		<string>Hybrid</string>
		<key>MDR Mode</key>
		<string>MDR SO33</string>
		<key>MIP Dereg Retries</key>
		<string>2</string>
		<key>MIP MN-AAA Shared Secret</key>
		<string>Default:767A77</string>
		<key>MIP MN-HA Shared Secret</key>
		<string>Default:74657374746573747465737474657324</string>
		<key>MIP Mode</key>
		<string>MIP Preferred</string>
		<key>MIP NAI</key>
		<string>Default:001[HMEID]@vzw3g.com</string>
		<key>MIP Pre-Reregistration Timeout</key>
		<integer>0</integer>
		<key>MIP Registration Retries</key>
		<integer>2</integer>
		<key>MIP Registration Retry Timeout</key>
		<integer>3</integer>
		<key>MN AAA SPI Set</key>
		<true/>
		<key>MN AAA SPI Value</key>
		<string>2</string>
		<key>MN HA SPI Set</key>
		<true/>
		<key>MN HA SPI Value</key>
		<integer>300</integer>
		<key>MN_Authenticator</key>
		<string>111111base10</string>
		<key>Mobile Node - HA Authentication</key>
		<string>RFC2002bis</string>
		<key>Number of Profiles</key>
		<integer>1</integer>
		<key>PREF_FOR_RC</key>
		<string>RC3</string>
		<key>QNC Enabled</key>
		<false/>
		<key>Reverse Tunneling</key>
		<true/>
		<key>SIP NAI</key>
		<string>Default:001[HMEID]@vzw3g.com</string>
		<key>SIP Password</key>
		<string>Default:00000000000000000000000000000000</string>
	</dict>
	<key>EHRPD</key>
	<dict>
		<key>Enable EHRPD</key>
		<false/>
		<key>HDRSCP Force AT Config</key>
		<string>1</string>
		<key>HDRSCP Session Re-negotiate</key>
		<true/>
	</dict>
	<key>Feature Settings</key>
	<dict>
		<key>Handset Based Plus Code Dialing</key>
		<true/>
		<key>NAM_LOCK</key>
		<false/>
		<key>OTAPA Enabled</key>
		<false/>
		<key>Preferred Mode</key>
		<string>CDMA_HDR_ONLY</string>
		<key>RTRE Config</key>
		<string>RUIM_CSIM_ONLY</string>
		<key>Roam Preference</key>
		<string>Home Only</string>
		<key>System Select Preference</key>
		<string>Automatic B</string>
	</dict>
	<key>JCDMA</key>
	<dict>
		<key>Enable JCDMA</key>
		<false/>
	</dict>
	<key>NAM - CDMA Settings</key>
	<dict>
		<key>ACCOLOC</key>
		<string>Default:[pESN1]</string>
		<key>EVRC Capability</key>
		<dict>
			<key>EVRC B Enable</key>
			<true/>
			<key>EVRC Capability</key>
			<dict>
				<key>EVRC Enable</key>
				<true/>
				<key>Preferred voice service option for Home Origination</key>
				<string>EVRC_A</string>
				<key>Preferred voice service option for Home Page</key>
				<string>EVRC_A</string>
				<key>Preferred voice service option for Roam Origination</key>
				<string>EVRC_A</string>
			</dict>
		</dict>
		<key>Home SID/NID</key>
		<array>
			<string>2004/65535</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
		</array>
		<key>IMSI_S</key>
		<string>Default:000000[pESN4]</string>
		<key>MCC</key>
		<string>310</string>
		<key>MIN1</key>
		<string>Default:000[pESN4]</string>
		<key>MIN2</key>
		<string>Default:000</string>
		<key>MNC</key>
		<string>0</string>
		<key>Negative SID/NID</key>
		<array>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
			<string>0/0</string>
		</array>
		<key>Primary Channel, A band</key>
		<integer>283</integer>
		<key>Primary Channel, B band</key>
		<integer>384</integer>
		<key>Register - Foreign NID</key>
		<true/>
		<key>Register - Foreign SID</key>
		<true/>
		<key>Register - Home SID</key>
		<true/>
		<key>Secondary Channel, A band</key>
		<integer>691</integer>
		<key>Secondary Channel, B band</key>
		<integer>777</integer>
		<key>Slot Cycle Index</key>
		<integer>2</integer>
		<key>Voice Privacy</key>
		<true/>
	</dict>
	<key>NAM - General</key>
	<dict>
		<key>MDN</key>
		<string>Default:000000[pESN4]</string>
	</dict>
	<key>SMS / EMS Settings</key>
	<dict>
		<key>MO-SMS SO</key>
		<string>SO_6 (8k)</string>
		<key>MO-SMS enable</key>
		<true/>
		<key>Resend Count</key>
		<integer>3</integer>
		<key>Transport Methods</key>
		<string>Traffic Channel</string>
	</dict>
	<key>Security Grouping</key>
	<dict>
		<key>Service Programming Code (SPC)</key>
		<string>000000</string>
		<key>Service Programming Code Change Enabled</key>
		<false/>
	</dict>
</dict>
</plist>
